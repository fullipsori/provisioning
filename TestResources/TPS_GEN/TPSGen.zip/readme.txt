maven build 를 통해 executable jar를 만드는 방법
 
1. local repository 에 install 한다.
 - mvn install:install-file -Dfile=tibjms.jar -DgroupId=tibjms -DartifactId=tibjms -Dversion=1.0 -Dpackaging=jar -DgeneratePom=true
2. mvn clean initialize compile assembly:single
