import java.io.ByteArrayOutputStream;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class TestClass {
    public interface Common {
        void print();
    }

    public static byte[] convertObjectToBytes(Object obj){
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ObjectOutputStream os = new ObjectOutputStream(out);
            os.writeObject(obj);
            return out.toByteArray();
        }catch (Exception e) { return null; }
    }

    public static Object convertBytesToObject(byte[] data) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(data);
            ObjectInputStream is = new ObjectInputStream(in);
            return is.readObject();
        }catch (Exception e) { return null; }
    }

    public static class TestA implements Common {
        public Object handle = null;

        @Override
        public void print() {
            System.out.println("TestA");
        }

        public TestA(String server, int port) {
            try {
                handle = new Socket();
            }catch (Exception e){
                System.out.println("Exception:"+ e.getMessage());
            }
        }
    }

    public static class TestB implements Common {
        public String handle = null;

        @Override
        public void print() {
            System.out.println("TestA");
        }

        public TestB(String data) {
            handle = data;
        }
    }

    public static Map<String, Common> mapData = new HashMap<>();

    public static void main(String[] args) {
        mapData.put("testA", new TestA("127.0.0.1", 9101));
        mapData.put("testB", new TestB("testB"));

        for(Map.Entry<String, Common> entry : mapData.entrySet()) {
            if(entry.getValue() instanceof TestA) {
                Object handle = ((TestA)entry.getValue()).handle;
                if(handle == null) {
                    System.out.println("null");
                }else if(!(handle instanceof Socket)){
                    System.out.println("not socket");
                }else{
                    System.out.println("not null");
                }
            }else{
                System.out.println("resultB:" + ((TestB)entry.getValue()).handle);
            }
        }

    }
}
